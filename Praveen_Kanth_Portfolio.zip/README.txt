# Praveen Kanth Portfolio Website
Upload this folder to GitHub Pages, Netlify, or Vercel to host your portfolio.
